# 第二代｜Marianne Vale

> 来源：`/home/russell/Downloads/轮回诅咒流程+材料.pdf`

第二代：Marianne Vale
美术照片：死亡现场足印照片（打滑胶鞋印），尸体，证物：胶鞋，药，胸针，字条
